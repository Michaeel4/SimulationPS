package desmoj.extensions.visualization2d.animation.core.simulator;

public interface ListInterface {

	public String getInternId();
}
